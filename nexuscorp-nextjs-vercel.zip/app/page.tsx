export default function Home(){
return (
<main style={{padding:'40px'}}>
<h1>Nexus-Corp KBDSS</h1>
<p>Proyecto listo para desplegar en Vercel.</p>
<div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'16px',marginTop:'20px'}}>
<div style={{padding:'20px',background:'#1e293b',borderRadius:'12px'}}>Adopción: 72%</div>
<div style={{padding:'20px',background:'#1e293b',borderRadius:'12px'}}>Precisión: 87%</div>
<div style={{padding:'20px',background:'#1e293b',borderRadius:'12px'}}>Reglas: 6</div>
<div style={{padding:'20px',background:'#1e293b',borderRadius:'12px'}}>Calificación: 4.6/5</div>
</div>
</main>
)}